/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.NoResultException;
import javax.persistence.Persistence;
import javax.persistence.RollbackException;
import javax.persistence.TypedQuery;

/**
 *
 * @author lucas
 */
public class ProdutoDAO {

    private EntityManagerFactory conn;
    private EntityManager manager;

    public void conectar() {
        conn = Persistence.createEntityManagerFactory("webPU");
        manager = conn.createEntityManager();

    }

    public int salvarProduto(Produto prod) {
        conectar();
        try {
            manager.getTransaction().begin();
            manager.persist(prod);
            manager.getTransaction().commit();
            return 1;
        } catch (RollbackException ex) {
            return 2;
        } catch (Exception ex) {
            return 3;
        }
    }

    public List<Produto> listarProdutos() {
        conectar();
        {
            try {
                TypedQuery<Produto> query = manager.createNamedQuery("Produto.findAll", Produto.class);
                List<Produto> produtos = query.getResultList();
                return produtos;
            } catch (NoResultException ex) {
                return null;
            }
        }
    }

    public int excluirProduto(int id) {
        conectar();

        try {
            Produto prod = manager.find(Produto.class, id);
            if (prod == null) {
                return 2;
            } else {

                manager.getTransaction().begin();
                manager.remove(prod);
                manager.getTransaction().commit();
                return 1; // Deu certo
            }
        } catch (Exception ex) {
            return 0; //Deu qualquer outro erro
        }

    }

public int alterarProduto(int idProd, String nomeProd, Double precoProd) {
        conectar();
        try {
            Produto prod = manager.find(Produto.class, idProd);
            prod.setNomeProduto(nomeProd);
            prod.setPrecoProduto(precoProd);
            manager.getTransaction().begin();
            manager.merge(prod);
            manager.getTransaction().commit();
            return 1; // Deu certo
        } catch (Exception ex) {
            return 0; //Deu qualquer erro
        }
    }

    public Produto buscarProduto(int idProd) {
        conectar();
        try {
            Produto prod = manager.find(Produto.class, idProd);
            return prod;
        } catch (Exception ex) {
            return null;
        }
    }

    public Produto consultarProduto(int id) {
        conectar();
        try {
            TypedQuery queryId = manager.createNamedQuery("Produto.findByIdProduto", Produto.class);
            queryId.setParameter("idproduto", id);
            Produto prod = (Produto) queryId.getSingleResult();
            return prod;
        } catch (NoResultException ex) {
            return null;
        }
    }

}
